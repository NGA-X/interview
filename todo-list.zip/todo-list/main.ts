interface IData {
    [key: string]: string | Array<IData> | IData;
}

type ValueType = string | Array<IData> | IData;

function checkValueType(value: ValueType) {
    const typeString = Object.prototype.toString.call(value);

    switch(typeString) {
        case '[object Object]':
            return 'Object';
        case '[object String]':
            return 'String';
        case '[object Array]':
            return 'Array';
        default:
            return null
    }
}

function renderList(data: IData) {
    const _data = {...data};

    for(let item in _data) {
        const type = checkValueType(_data[item])

        if(type === 'String') {
            _data[item] = {
                option: 'Update',
                value: _data[item]
            }
        }

        if(type === 'Array') {
            _data[item] = {
                option: 'Update|Delete|Create',
                value: _data[item]
            }
        }

        if(type === 'Object') {
            _data[item] = renderList(_data[item] as IData)
        }
    }
    return _data;
}

const data: IData = {
    '中途採用比率': {'前年度/2年度前/3年度前': '10%20%30%'},
    '正社員の平均継続勤務年数': '18.5年',
    '育児休業取得率（男性）': [
      {'正社員': '34%'},
      {'専門職': '50%'},
    ],
    '育児休業取得率（女性）': [
      {'正社員': '34%'},
      {'専門職': '50%'},
    ],
};

const newData = renderList(data)
// 根据数据的 option 字段判断当前数据操作类型：
// Update：可更新
// Delete：可删除
// Create：可新增
console.log(newData)
