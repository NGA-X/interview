# TodoList Server

## 技术栈
NestJS + TS

## 建表语句
```sql
CREATE TABLE todolist.todo_list (
  `id` INT(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `state` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `delete_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
)
```

## 启动

- 开发环境：start:dev

## 构建

- 生产环境：build
