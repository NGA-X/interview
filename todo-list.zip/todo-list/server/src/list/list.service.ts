import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ListEntity } from './list.entity';
import { Repository } from 'typeorm';

@Injectable()
export class ListService {
  constructor(
    @InjectRepository(ListEntity)
    private readonly listRepository: Repository<ListEntity>,
  ) {}

  async getList(): Promise<any> {
    return {
      message: 'success',
      code: 0,
      data: await this.listRepository.find({
        order: { createTime: 'DESC' },
        select: ['id', 'title', 'state'],
      }),
    };
  }

  async addItem(item): Promise<any> {
    const list = await this.listRepository.insert(item);

    return {
      message: list ? 'success' : 'fail',
      code: list ? 0 : 1005,
      data: null,
    };
  }

  async updateItem(id: number): Promise<any> {
    const item = await this.listRepository.findOne({ where: { id: id } });
    const state = item.state === 0 ? 1 : 0;
    const result = await this.listRepository.update(
      { id: id },
      { state: state },
    );

    if (result && result.affected > 0) {
      return {
        message: 'success',
        code: 0,
        data: null,
      };
    } else {
      return {
        message: '更新失败',
        code: 1005,
        data: null,
      };
    }
  }
}
