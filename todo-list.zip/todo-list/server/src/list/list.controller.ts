import { Controller, Get, Post, Param, Body, Patch } from '@nestjs/common';

import { ListService } from './list.service';

@Controller('list')
export class ListController {
  constructor(private readonly listService: ListService) {}
  @Get('getAll')
  getAll(): any {
    return this.listService.getList();
  }

  @Post('add')
  create(@Body() data: any): any {
    return this.listService.addItem(data);
  }

  @Patch(':id')
  update(@Param('id') id: string): any {
    return this.listService.updateItem(Number(id));
  }
}
