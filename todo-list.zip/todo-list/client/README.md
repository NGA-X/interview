# TodoList Client

## 技术栈
Vite + React + TS

## 目录结构
```
|-- client
    |-- .eslintrc.cjs
    |-- .gitignore
    |-- README.md
    |-- index.html：HTML 模板文件
    |-- package-lock.json
    |-- package.json
    |-- tsconfig.json
    |-- tsconfig.node.json
    |-- vite.config.ts：vite 配置文件
    |-- yarn.lock
    |-- env：环境变量配置文件
    |   |-- .env.development
    |   |-- .env.production
    |   |-- .env.testing
    |-- public：固定静态资源
    |-- src
        |-- main.tsx
        |-- vite-env.d.ts
        |-- api：接口相关
        |   |-- todo-list.ts
        |-- assets：静态资源
        |   |-- banner.jpg
        |   |-- checked.svg
        |   |-- icon-moon.svg
        |-- components：组件
        |   |-- InputArea
        |   |   |-- index.tsx
        |   |   |-- style.module.less
        |   |-- ListArea
        |   |   |-- index.tsx
        |   |   |-- style.module.less
        |   |-- TodoList
        |       |-- index.tsx
        |       |-- style.module.less
        |-- pages：页面
        |   |-- 404
        |   |   |-- index.tsx
        |   |-- home
        |       |-- index.tsx
        |       |-- style.module.less
        |-- router：路由文件
        |   |-- index.ts
        |-- types：类型定义
        |   |-- index.ts
        |-- utils：工具库
            |-- hooks.ts
            |-- http.ts
```

## 运行

- 开发环境：start:dev
- 测试环境：start:test
- 生产环境：start:prod

## 构建

- 开发环境：build:dev
- 测试环境：build:test
- 生产环境：build:prod

