import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import 'normalize.css/normalize.css'
import routeConfig from './router';

const router = createBrowserRouter(routeConfig);

const root = createRoot(document.getElementById('root')!);
root.render(
  <StrictMode>
    <RouterProvider router={router} />
  </StrictMode>,
);
// root.render(<RouterProvider router={router} />);

