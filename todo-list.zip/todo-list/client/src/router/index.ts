import {lazy} from 'react';

import { RouteObject } from 'react-router-dom';

const routeConfig: RouteObject[] = [
  {
    path: '/', 
    Component: lazy(() => import('../pages/home')),
  },
  {
    path: '*',
    Component: lazy(() => import('../pages/404')),
  },
];

export default routeConfig;