import banner from '@/assets/banner.jpg'
import styles from './style.module.less'
import TodoList from '@/components/TodoList'

const Home = () => {
  return (
    <div className={styles.content}>
      <img src={banner} alt="banner" />
      <TodoList />
    </div>
  );
};

export default Home