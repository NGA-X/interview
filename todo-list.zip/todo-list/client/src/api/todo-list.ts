import instance from '@/utils/http'
import { IRecord } from '@/types'

interface IRes {
    code: number,
    message: string
    data: Array<IRecord>
}

interface IData {
    title: string,
    state: number
}

export const getList = (): Promise<IRes> => instance.get('/list/getAll');

export const addItem = (data: IData): Promise<IRes> => instance.post('/list/add', data);

export const updateState = (id: number): Promise<IRes> => instance.patch(`/list/${id}`);


