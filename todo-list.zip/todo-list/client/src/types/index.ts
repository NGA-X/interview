export interface IRecord {
    id: number,
    title: string,
    state: number
}
