// import { useState } from 'react'
import styles from './style.module.less'
import { IRecord } from '@/types'
import { updateState } from '@/api/todo-list'


type IProps = {
    list:  Array<IRecord>,
    updateList: () => void
}


const ListArea = (props: IProps) => {
    const {list, updateList} = props;

    const update = async (item: IRecord) => {
        const rest = await updateState(item.id)
        if(rest.code === 0) {
            updateList()
        }
    }

    return <div className={styles.wrap}>
        {
            list.length === 0 ? <p>没有数据~</p> : (
                <ul className={styles.listWrap}>
                    {
                        list.map((item) => <li key={item.id} onClick={() => update(item)} className={item.state === 0 ? '' : styles.active}>{item.title}</li>)
                    }
                </ul>
            )
        }
    </div>
}

export default ListArea