import { useState, useEffect } from 'react'
import styles from './style.module.less'
import moon from '@/assets/icon-moon.svg'
import InputArea from '@/components/InputArea'
import ListArea from '@/components/ListArea'
import { getList } from '@/api/todo-list'
import { IRecord } from '@/types'

const TodoList = () => {
  const title = import.meta.env.VITE_APP_TITLE;
  const [list, setList] = useState<IRecord[]>([])

  const fetchList = async () => {
    const rest = await getList();

    if(rest.code === 0 && rest.data) {
      if(Array.isArray(rest.data)) {
        setList(rest.data)
      }
    }
  }

  useEffect(() => {
    fetchList()
  }, [])

  return (
    <div className={styles.wrap}>
        <div className={styles.title}>
            <h1>{title}</h1>
            <img src={moon} alt="moon" />
        </div>
        <InputArea updateList={fetchList} />
        <ListArea list={list} updateList={fetchList} />
    </div>
  );
};

export default TodoList