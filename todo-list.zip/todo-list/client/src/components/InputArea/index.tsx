import {useState} from 'react'
import styles from './style.module.less'
import { addItem } from '@/api/todo-list'

type IProps = {
    updateList: () => void
}

const InputArea = (props: IProps) => {
    const {updateList} = props;
    const [value, setValue] = useState('');

    const handleKeyDown = async (event: React.KeyboardEvent<HTMLInputElement>) => {
        if(!value) return;

        if (event.key === 'Enter') {
            const rest = await addItem({title: value, state: 0})
            console.log(rest)
            alert(rest)
            if(rest.code === 0) {
                setValue('')
                updateList()
            }
        }
    };
    return <div className={styles.wrap}>
        <input
            type="text"
            placeholder='请输入待办事项' 
            value={value}
            onChange={e => setValue(e.target.value)}
            onKeyDown={handleKeyDown}
         />
    </div>
}

export default InputArea