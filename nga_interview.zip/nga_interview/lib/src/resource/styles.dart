import 'package:flutter/material.dart';

final class Styles {
  static BoxDecoration get editableBox {
    return BoxDecoration(
      color: Colors.blue.withOpacity(.2),
      borderRadius: BorderRadius.circular(8),
    );
  }
}
