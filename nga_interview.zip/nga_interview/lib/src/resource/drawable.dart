// ignore_for_file: constant_identifier_names

final class Drawables {
  static const bg_dialog = 'assets/images/bg_dialog.png';
}
