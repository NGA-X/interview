import 'package:decorated_flutter/decorated_flutter.dart';
import 'package:flutter/material.dart';
import 'package:nga_interview/src/ui/dialog/dialog.export.dart';
import 'package:nga_interview/src/ui/widget/widget.export.dart';

class MapItem extends StatefulWidget {
  MapItem(this._title, this._value) : super(key: Key(_title));

  final String _title;
  final Map<String, String> _value;

  @override
  State<MapItem> createState() => _MapItemState();
}

class _MapItemState extends State<MapItem> {
  late Map<String, String> _state;

  @override
  void initState() {
    super.initState();
    _state = widget._value;
  }

  @override
  Widget build(BuildContext context) {
    return Section(
      itemSpacing: 12,
      childrenFlex: const FlexConfig.flexible([1, 2, 2]),
      children: [
        DecoratedText(widget._title, textAlign: TextAlign.center),
        if (_state.isNotEmpty) ...[
          Text(_state.entries.first.key, textAlign: TextAlign.center),
          EditableValue(
            title: widget._title,
            value: _state.entries.first.value,
            onChange: (newValue) =>
                _handleChangeValue(_state.entries.first.key, newValue),
          ),
        ],
      ],
    );
  }

  void _handleChangeValue(String key, String value) async {
    final result = await showMapDialog(
      context,
      title: widget._title,
      subtitles: widget._value.entries.first.key.split('/'),
      values: widget._value.entries.first.value.split('/'),
    );
    if (result == null) return;

    setStateSafely(() {
      _state[key] = result;
    });
  }
}
