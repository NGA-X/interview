import 'package:decorated_flutter/decorated_flutter.dart';
import 'package:flutter/material.dart';
import 'package:nga_interview/src/ui/dialog/dialog.export.dart';
import 'package:nga_interview/src/ui/widget/widget.export.dart';

class StringItem extends StatefulWidget {
  StringItem(this._title, this._value) : super(key: Key(_title));

  final String _title, _value;

  @override
  State<StringItem> createState() => _StringItemState();
}

class _StringItemState extends State<StringItem> {
  late String _state;

  @override
  void initState() {
    super.initState();
    _state = widget._value;
  }

  @override
  Widget build(BuildContext context) {
    return Section(
      children: [
        DecoratedText(
          widget._title,
          constraints: const BoxConstraints(maxWidth: 200),
        ),
        EditableValue(
          title: widget._title,
          value: _state,
          onChange: _handleChange,
        ),
      ],
    );
  }

  void _handleChange(String value) async {
    final result = await showStringDialog(
      context,
      title: widget._title,
      initialValue: value,
    );
    if (result == null) return;

    setStateSafely(() {
      _state = result;
    });
  }
}
