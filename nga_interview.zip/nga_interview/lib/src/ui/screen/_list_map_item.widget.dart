import 'package:decorated_flutter/decorated_flutter.dart';
import 'package:flutter/material.dart';
import 'package:nga_interview/src/resource/styles.dart';
import 'package:nga_interview/src/ui/dialog/dialog.export.dart';
import 'package:nga_interview/src/ui/widget/widget.export.dart';

class ListMapItem extends StatefulWidget {
  ListMapItem(this._title, this._value) : super(key: Key(_title));

  final String _title;
  final List<Map<String, String>> _value;

  @override
  State<ListMapItem> createState() => _ListMapItemState();
}

class _ListMapItemState extends State<ListMapItem> {
  late List<Map<String, String>> _state;

  @override
  void initState() {
    super.initState();
    _state = widget._value;
  }

  @override
  Widget build(BuildContext context) {
    return Section(
      children: [
        DecoratedText(widget._title, width: 96),
        SPACE_16_HORIZONTAL,
        DecoratedColumn(
          expanded: true,
          children: [
            /// 列表值
            DecoratedColumn(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              divider: const Line(
                color: Colors.black12,
                margin: EdgeInsets.only(top: 8),
              ),
              children: [
                for (final (index, item) in widget._value.indexed)
                  DeletableValue(
                    item.entries.first,
                    onEdit: () => _handleEdit(index: index),
                    onDeleted: () => _handleRemove(item),
                  ),
              ],
            ),
            SPACE_12_VERTICAL,

            /// 增加 按钮
            GestureDetector(
              onTap: _handleEdit,
              child: DashedContainer(
                decoration: Styles.editableBox,
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: const Icon(Icons.add, color: Colors.blue),
                ),
              ),
            )
          ],
        ),
      ],
    );
  }

  void _handleRemove(Map<String, String> item) {
    setStateSafely(() {
      _state.remove(item);
    });
  }

  void _handleEdit({int? index}) async {
    final result = await showListMapDialog(
      context,
      title: widget._title,
      entry: index != null ? _state[index].entries.first : null,
    );
    if (result == null) return;

    setStateSafely(() {
      if (index != null) {
        _state.replace(index, {result.key: result.value});
      } else {
        _state.add({result.key: result.value});
      }
    });
  }
}
