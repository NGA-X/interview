import 'package:decorated_flutter/decorated_flutter.dart';
import 'package:flutter/material.dart';
import 'package:nga_interview/src/data/data.dart';

import '_list_map_item.widget.dart';
import '_map_item.widget.dart';
import '_string_item.widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text('NGA Interview'),
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(12),
        itemCount: dataMap.length,
        itemBuilder: (_, index) {
          final data = dataMap.entries[index];
          if (data == null) return NIL;

          final key = data.key;
          return switch (data.value) {
            String value => StringItem(key, value),
            Map<String, String> value => MapItem(key, value),
            List<Map<String, String>> value => ListMapItem(key, value),
            _ => NIL
          };
        },
        separatorBuilder: (_, __) => SPACE_12_VERTICAL,
      ),
    );
  }
}
