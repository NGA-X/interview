import 'package:decorated_flutter/decorated_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:nga_interview/src/resource/drawable.dart';

/// 只有一个值的对话框
@useResult
Future<String?> showStringDialog(BuildContext context,
    {required String title, required String initialValue, e}) {
  return showDialog(
    context: context,
    builder: (context) => Dialog(
      clipBehavior: Clip.hardEdge,
      child: Form(
        child: _MapDialog(title: title, initialValue: initialValue),
      ),
    ),
  );
}

class _MapDialog extends StatelessWidget {
  _MapDialog({
    Key? key,
    required this.title,
    required String initialValue,
  })  :
        // !数据和单位分离, 应该由数据提供方提供更多信息
        initialValue = initialValue.substring(0, initialValue.length - 1),
        unit = initialValue.characters.last,
        super(key: key);

  final String title, initialValue, unit;

  @override
  Widget build(BuildContext context) {
    return DecoratedColumn(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
      decoration: const BoxDecoration(
        image: DecorationImage(
          fit: BoxFit.cover,
          image: AssetImage(Drawables.bg_dialog),
        ),
      ),
      mainAxisSize: MainAxisSize.min,
      children: [
        Text('$title(单位: $unit)', textAlign: TextAlign.center),
        SPACE_12_VERTICAL,
        TextFormField(
          validator: (value) => value?.doubleValue == null ? '请输入有效数据' : null,
          onSaved: (value) => context.rootNavigator.pop('$value$unit'),
          initialValue: initialValue,
          keyboardType: TextInputType.number,
          // !具体什么格式, 需要更多的信息
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp(r'[0-9]|\.'))
          ],
          style: const TextStyle(fontSize: 14),
        ),
        SPACE_16_VERTICAL,
        ElevatedButton(
          onPressed: () => _handleConfirm(context),
          child: const Text('确定'),
        ),
      ],
    );
  }

  void _handleConfirm(BuildContext context) {
    if (context.form.validate()) {
      context.form.save();
    }
  }
}
