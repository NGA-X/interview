import 'package:decorated_flutter/decorated_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:nga_interview/src/resource/drawable.dart';

/// 采用比率
@useResult
Future<String?> showMapDialog(
  BuildContext context, {
  required String title,
  required List<String> subtitles,
  required List<String> values,
}) {
  return showDialog(
    context: context,
    builder: (context) => Dialog(
      clipBehavior: Clip.hardEdge,
      child: Form(
        child: _MapMapDialog(
          title: title,
          titles: subtitles,
          values: values,
        ),
      ),
    ),
  );
}

class _MapMapDialog extends StatelessWidget {
  _MapMapDialog({
    Key? key,
    required this.title,
    required this.titles,
    required List<String> values,
  })  : controllers = [
          for (final item in values)
            TextEditingController(text: item.replaceFirst('%', ''))
        ],
        super(key: key);

  final String title;
  final List<String> titles;
  final List<TextEditingController> controllers;

  @override
  Widget build(BuildContext context) {
    return DecoratedColumn(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
      decoration: const BoxDecoration(
        image: DecorationImage(
          fit: BoxFit.cover,
          image: AssetImage(Drawables.bg_dialog),
        ),
      ),
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          title,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w500,
          ),
        ),
        SPACE_16_VERTICAL,
        for (final (index, item) in titles.indexed) ...[
          Text('$item(单位: %)'),
          SPACE_2_VERTICAL,
          TextFormField(
            style: const TextStyle(fontSize: 14),
            decoration: InputDecoration(hintText: '$item中途採用比率'),
            // ! 检查数据
            validator: (value) => isEmpty(value) ? '请输入数据' : null,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            keyboardType: TextInputType.number,
            controller: controllers[index],
          ),
          SPACE_8_VERTICAL,
        ],
        SPACE_12_VERTICAL,
        ElevatedButton(
          onPressed: () => _handleConfirm(context),
          child: const Text('确定'),
        ),
      ],
    );
  }

  void _handleConfirm(BuildContext context) {
    if (context.form.validate()) {
      context.rootNavigator
          .pop([for (final item in controllers) '${item.text}%'].join('/'));
    }
  }
}
