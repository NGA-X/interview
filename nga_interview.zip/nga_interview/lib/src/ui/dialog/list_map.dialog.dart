import 'package:decorated_flutter/decorated_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:nga_interview/src/resource/drawable.dart';

/// 包含键值对的对话框
@useResult
Future<MapEntry<String, String>?> showListMapDialog(
  BuildContext context, {
  required String title,
  MapEntry<String, String>? entry,
}) {
  return showDialog<MapEntry<String, String>>(
    context: context,
    builder: (context) => Dialog(
      clipBehavior: Clip.hardEdge,
      child: Form(
        child: _MapListDialog(
          title: title,
          entry: entry ?? const MapEntry('', ''),
        ),
      ),
    ),
  );
}

class _MapListDialog extends StatelessWidget {
  _MapListDialog({
    required this.title,
    required MapEntry<String, String> entry,
  })  : keyController = TextEditingController(text: entry.key),
        valueController =
            TextEditingController(text: entry.value.replaceAll('%', ''));

  final String title;
  final TextEditingController keyController;
  final TextEditingController valueController;

  @override
  Widget build(BuildContext context) {
    return DecoratedColumn(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
      decoration: const BoxDecoration(
        image: DecorationImage(
          fit: BoxFit.cover,
          image: AssetImage(Drawables.bg_dialog),
        ),
      ),
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          title,
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w500),
        ),
        SPACE_24_VERTICAL,
        Text.rich(
          TextSpan(
            children: [
              if (keyController.text.isEmpty)
                const TextSpan(
                  text: '*',
                  style: TextStyle(color: Colors.red),
                ),
              const TextSpan(text: '職種'),
            ],
          ),
        ),
        SPACE_4_VERTICAL,
        TextFormField(
          controller: keyController,
          style: const TextStyle(fontSize: 14),
          // ! 完整的数据检查
          validator: (value) => isEmpty(value) ? '请输入数据' : null,
          decoration: const InputDecoration(hintText: '職種を入力してください'),
        ),
        SPACE_12_VERTICAL,
        Text.rich(
          TextSpan(
            children: [
              if (valueController.text.isEmpty)
                const TextSpan(
                  text: '*',
                  style: TextStyle(color: Colors.red),
                ),
              const TextSpan(
                text: '割合(単位：%)',
                style: TextStyle(color: Colors.black),
              ),
            ],
          ),
        ),
        SPACE_4_VERTICAL,
        TextFormField(
          controller: valueController,
          style: const TextStyle(fontSize: 14),
          keyboardType: TextInputType.number,
          // ! 完整的数据检查
          validator: (value) => isEmpty(value) ? '请输入数据' : null,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          decoration: const InputDecoration(hintText: '割合を入力してください'),
        ),
        SPACE_16_VERTICAL,
        ElevatedButton(
          onPressed: () => _handleConfirm(context),
          child: const Text('确定'),
        ),
      ],
    );
  }

  void _handleConfirm(BuildContext context) {
    if (context.form.validate()) {
      context.rootNavigator.pop(
          MapEntry(keyController.text, valueController.text.suffixWith('%')));
    }
  }
}
