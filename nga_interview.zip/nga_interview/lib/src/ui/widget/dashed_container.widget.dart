import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';

class DashedContainer extends StatelessWidget {
  const DashedContainer({
    super.key,
    required this.child,
    this.decoration,
    this.padding = EdgeInsets.zero,
  });

  final EdgeInsets padding;
  final BoxDecoration? decoration;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return DottedBorder(
      borderType: BorderType.RRect,
      radius: const Radius.circular(8),
      color: Colors.blue,
      padding: padding,
      child: Container(decoration: decoration, child: child),
    );
  }
}
