import 'package:decorated_flutter/decorated_flutter.dart';
import 'package:flutter/material.dart';
import 'package:nga_interview/src/resource/styles.dart';

import 'dashed_container.widget.dart';

class EditableValue extends StatelessWidget {
  const EditableValue({
    super.key,
    required this.title,
    required this.value,
    required this.onChange,
  });

  final String title, value;
  final ValueChanged<String> onChange;

  @override
  Widget build(BuildContext context) {
    return DashedContainer(
      decoration: Styles.editableBox,
      child: DecoratedText(
        value,
        onPressed: (_) => onChange(value),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        textAlign: TextAlign.right,
        widgetPadding: 4,
        style: const TextStyle(fontSize: 12),
        rightWidget: const Icon(Icons.edit, color: Colors.blue, size: 14),
      ),
    );
  }
}
