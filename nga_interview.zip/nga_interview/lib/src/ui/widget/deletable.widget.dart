import 'package:decorated_flutter/decorated_flutter.dart';
import 'package:flutter/material.dart';
import 'package:nga_interview/src/resource/styles.dart';

import 'dashed_container.widget.dart';

class DeletableValue extends StatelessWidget {
  const DeletableValue(
    this.value, {
    super.key,
    required this.onDeleted,
    required this.onEdit,
  });

  final MapEntry<String, String> value;
  final VoidCallback onDeleted;
  final VoidCallback onEdit;

  @override
  Widget build(BuildContext context) {
    return DecoratedStack(
      onPressed: (_) => onEdit(),
      topRight: GestureDetector(
        onTap: onDeleted,
        child: const Icon(Icons.remove_circle, color: Colors.red),
      ),
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: DashedContainer(
            decoration: Styles.editableBox,
            child: DecoratedRow(
              padding: const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 8,
              ),
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [Text(value.key), Text(value.value)],
            ),
          ),
        ),
      ],
    );
  }
}
