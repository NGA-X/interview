import 'package:decorated_flutter/decorated_flutter.dart';
import 'package:flutter/material.dart';

class Section extends StatelessWidget {
  const Section({
    super.key,
    required this.children,
    this.childrenFlex,
    this.itemSpacing = 0,
  });

  final FlexConfig? childrenFlex;
  final double itemSpacing;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return DecoratedRow(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.black12),
      ),
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      textStyle: const TextStyle(fontSize: 13),
      childrenFlex: childrenFlex,
      itemSpacing: itemSpacing,
      children: children,
    );
  }
}
