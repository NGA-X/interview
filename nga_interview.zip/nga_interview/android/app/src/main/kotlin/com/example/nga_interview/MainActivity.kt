package com.example.nga_interview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
